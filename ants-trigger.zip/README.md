# cloud-function-ants
## before you start
have python installed: brew install python
have firebase-admin installed :pip3 install firebase-admin

## execute scripts
### To upload products from json
python3 uploadproducts.py   
### To discount random products
It make take a bit of time to execute
python3 discout.py   

docker build --platform linux/amd64 -t ants-trigger -t gcr.io/ingka-native-ikealabs-dev/ants-trigger:latest .
docker push gcr.io/ingka-native-ikealabs-dev/ants-trigger     

